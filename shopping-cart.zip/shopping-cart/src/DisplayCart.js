import React from 'react'

class DisplayCart extends React.Component
{
    render()
    {
        console.log(this.props.cartArr)
              return (
            <h1>DisplayCart Componnet</h1>
        )
    }
}

export default DisplayCart