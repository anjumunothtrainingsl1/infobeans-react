import React from 'react'
import Products from "./Products"
import AddToCart from "./AddToCart"

class DisplayProducts extends React.Component
{
    constructor()
    {
        super()
        var tempArray=[
            new Products(101,"Acer Laptop","The best acer laptop",46578,10,"./acer.jpg"),
            new Products(102,"HP Laptop","The best HP laptop",76578,10,"./hp.jpg"),
            new Products(103,"Apple Mac Laptop","The best Apple laptop",146578,10,"./mac.jpg"),
            new Products(104,"Dell Laptop","The best Dell laptop",99578,10,"./dell.jpg"),
            
            ]
        this.state={productsArray:tempArray,showAddToCart:false,productSelected:{}}

    }
    buyEventHandler=(p1)=>{
        this.setState({showAddToCart:true,productSelected:p1})
        console.log("Item selected",p1)
    }
    myEventHandler=(p1)=>{
        console.log("Data from AddToCart",p1)
        this.setState({showAddToCart:false})
        var pos=this.state.productsArray.findIndex(item =>item.productId == p1.productId)
        if(pos>=0)
        {   
            var obj={...this.state.productsArray[pos]};
            obj.quantity=obj.quantity-p1.quantitySelected
            this.setState((prevState)=>{
                var tempArr=[...this.state.productsArray]
                tempArr.splice(pos,1,obj)
                var tempState={...prevState,productsArray:tempArr}
                return tempState
            },()=>{
                this.props.onDataFromDP(p1)
            })
        }
        
    }
    render()
    {
        var cardArr=this.state.productsArray.map((item)=>{
            return(
                <div>
                    <div className="card" style={{width:"18rem"}}>
                        <div>
                            <img src={item.imageUrl} alt={item.description} className="card-img-top"/>
                        </div>
                        <div className="card-body">
                            <h2 className="card-title">{item.productName}</h2>
                            <p className="card-text">{item.description}</p>
                            <p className="card-text">Price : Rs.{item.price}</p>
                            <p className="card-text">Quantity Available {item.quantity}</p>
                            <input type="button" value="Buy" className="btn btn-primary" onClick={this.buyEventHandler.bind(this,item)} />

                           </div>

                    </div>
                </div>
            )

        })
        return (
            <React.Fragment>
            <h1>DisplayProducts Componnet</h1>
            <div className="card-group">
                {cardArr}
            </div>
            {this.state.showAddToCart&& <AddToCart onMyEvent={this.myEventHandler} productSelected={this.state.productSelected} dummyField={2*2}></AddToCart>}
                        
            </React.Fragment>
        )
    }
}

export default DisplayProducts