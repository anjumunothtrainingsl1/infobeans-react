import React from 'react'

class AddToCart extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state={quantitySelected:1,productSelected:{...props.productSelected},dummystate:798}
    }
    static getDerivedStateFromProps(nextProps,prevState)
    {
        if(nextProps.productSelected.productId != prevState.productSelected.productId)
        {
            var tempObj={...prevState,quantitySelected:1,productSelected:{...nextProps.productSelected}}
            
            return tempObj
        }
        return prevState

    }
    changeQuantityEventHandler=(p1)=>{
        if(p1=="inc")
        {
            if(this.state.quantitySelected < this.props.productSelected.quantity)
            {
                //this.setState({quantitySelected:this.state.quantitySelected+1})
                this.setState((prevState)=>{
                    var tempObj={...prevState,quantitySelected:prevState.quantitySelected+1}
                    return tempObj
                })
                
            }
        }
        else
        {
            if(this.state.quantitySelected >=2)
            {
                this.setState((prevState)=>{
                    var tempObj={...prevState,quantitySelected:prevState.quantitySelected-1}
                    return tempObj;
                })
            }
        }
    }
    
    addToCartEventHandler=()=>{
        var tempObj={...this.props.productSelected,quantitySelected:this.state.quantitySelected}
        this.props.onMyEvent(tempObj)
        
    }
    render()
    {
        console.log(this.props.productSelected)
        var item=this.props.productSelected;
        return(
            <React.Fragment>
                <h1>Add to Cart Component</h1>
                <div className="card bg-success text-light" style={{width:"18rem"}}>
                        <div>
                            <img src={item.imageUrl} alt={item.description} className="card-img-top"/>
                        </div>
                        <div className="card-body">
                            <h2 className="card-title">{item.productName}</h2>
                            <p className="card-text">{item.description}</p>
                            <p className="card-text">Price : Rs.{item.price}</p>
                            <p className="card-text">Quantity Available {item.quantity}</p>
                            <input type="button" value="+" onClick={this.changeQuantityEventHandler.bind(this,"inc")} />
                            {this.state.quantitySelected}
                            <input type="button" value="-" onClick={this.changeQuantityEventHandler.bind(this,"dec")}/>
                            <input type="button" value="Add To Cart" onClick={this.addToCartEventHandler} />
                           </div>

                    </div>
            </React.Fragment>
        )
    }
}
export default AddToCart