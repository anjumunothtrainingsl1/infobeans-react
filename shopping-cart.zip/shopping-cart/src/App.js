import logo from './logo.svg';
import React from "react"
import Header from './Header';
import DisplayCart from './DisplayCart';
import DisplayProducts from './DisplayProducts';
import Parent from './Parent';

class App extends React.Component {
  constructor()
  {
    super()
    this.state={showCart:false,cartArr:[]}
  }
  showComponentEventHandler=(p1)=>{
    this.setState({showCart:p1})

  }
  onDataFromDPEventHandler=(p1)=>{
    console.log("Data from Dp",p1)
    this.setState((prevState)=>{
      var tempCartArr=[...this.state.cartArr]
      tempCartArr.push(p1)
      return {...prevState,cartArr:tempCartArr}
    })

  }
  render() {
    console.log("Cart Arr",this.state.cartArr)
    return (
      <React.Fragment>
        <Header></Header>
        <Parent></Parent>
        <br/>

        <input type="button" value="Show Cart" className="btn btn-primary" onClick={this.showComponentEventHandler.bind(this,true)}/>
        <input type="button" value="Show Products" className="btn btn-primary" onClick={this.showComponentEventHandler.bind(this,false)}/>
        {this.state.showCart?
        <DisplayCart cartArr={this.state.cartArr}></DisplayCart>:
        <DisplayProducts onDataFromDP={this.onDataFromDPEventHandler}></DisplayProducts>}
      </React.Fragment>
    
  );
  }
}

export default App;
