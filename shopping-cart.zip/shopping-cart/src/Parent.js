import React from 'react'
import Child from './Child'

class Parent extends React.Component
{
    clickEventHandler=(p1)=>{
        console.log("Onclick triggered"+p1)
    }
    render()
    {
        return(
            <React.Fragment>
                <h1> Parent Component</h1>
                <Child sendDataToChild={1*2} onMyClick={this.clickEventHandler}></Child>
            </React.Fragment>
        )

    }
}

export default Parent