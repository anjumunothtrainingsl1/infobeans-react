import React from 'react'
import infobeansLogo from "./infobeansLogo.jpg"
import "./Header.css"

class Header extends React.Component
{
    render()
    {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-4">
                        <img src={infobeansLogo} alt="Logo" id="imgLogo"/>
                    </div>
                    <div className="col-8">
                        Shopping Cart
                    </div>
                </div>
            </div>
             )
    }
}

export default Header