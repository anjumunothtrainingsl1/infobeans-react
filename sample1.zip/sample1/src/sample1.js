var obj={empId:101,empName:"sara",salary:768,
printDetails:function()
{
    console.log("EmpId"+this.empId)
}}