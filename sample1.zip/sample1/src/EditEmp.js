import React, { Component } from 'react'
class EditEmp extends Component
{
    constructor(props)
    {
        super(props)
        console.log(this.props.empEditable)
        

    }
    render()
    {
        
        console.log(this.props.empEditable)
        return(
            <React.Fragment>
            <h1>Edit emp Component</h1>
            <div>{this.props.empEditable.empId}</div>
            </React.Fragment>
        );
    }
}
export default EditEmp;