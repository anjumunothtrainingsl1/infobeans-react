import React,{Component} from "react"
import EditEmp from "./EditEmp";

class MainContent extends Component
{
    empArray;
    showEditEmp;
    constructor()
    {
        super();
        this.state={showEditEmp:false,empArray:[{empId:101,empName:"Asha",salary:1001,deptId:"D1"},{empId:102,empName:"Gaurav",salary:2000,deptId:"D1"},{empId:103,empName:"Karan",salary:2000,deptId:"D2"},
        {empId:104,empName:"Kishan",salary:3000,deptId:"D1"},
        {empId:105,empName:"Keshav",salary:3500,deptId:"D2"},
        {empId:106,empName:"Pran",salary:4000,deptId:"D3"},
        {empId:107,empName:"Saurav",salary:3800,deptId:"D3"}]}

        
    }
    editEmployeeEventhandler=(obj)=>{
        console.log(obj)
        //this.state.showEditEmp=true
        this.setState({showEditEmp:true,empToBeEdited:obj})
        console.log("value of showEditEmp"+this.showEditEmp)
    }    
    addNewEmployeeEventHandler=(p1)=>
    {
        console.log(this.state.empArray)
    }
    render()
    {
        var trArray=this.state.empArray.map((emp)=>{
            return(
                <tr>
                    <td>
                        {emp.empId}
                    </td>
                    <td>
                        {emp.empName}
                    </td>
                    <td>
                        {emp.salary}
                    </td>
                    <td>
                        <input type="button" className="btn btn-primary" value="Edit" onClick={this.editEmployeeEventhandler.bind(this,emp)} />
                    </td>
                </tr>
            );
        })
        return(
            <div>
                <table className="table">
                    <thead>
                        <tr>
                            <th>
                                Employee Id
                            </th>
                            <th>
                                Employee Name
                            </th>
                            <th>
                                Salary
                            </th>
                            <th>
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        {trArray}
                    </tbody>
                </table>
                <input type="button" className="btn btn-primary" value="Add New employee" 
                onClick={this.addNewEmployeeEventHandler.bind(this,100)}/>

                {this.state.showEditEmp &&  <EditEmp empEditable={this.state.empToBeEdited}></EditEmp> }
                   
                </div>
        )
    }
}
export default MainContent