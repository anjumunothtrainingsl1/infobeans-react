import React,{Component} from "react"

class Menu extends Component
{
    render()
    {
        return(
            <div>
                <h1 className="bg-primary text-light">Menu Component</h1>
            </div>
        )
    }
}
export default Menu