import React from "react"
import infobeansLogo from "./infobeansLogo.jpg"
import "./Header.css"

class Header extends React.Component
{
    render()
    {
        var backgroundStyle={backgroundColor:"beige"}
        return (
            <div>
                <h1 className="fontClass" style={backgroundStyle}> Header component</h1>
                <div>
                    <img id="companyNameLogo" src={infobeansLogo} style={{border:"5px double cyan"}}/>
                </div>
            </div>
        )
    }

}

export default Header;