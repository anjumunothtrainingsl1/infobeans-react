import logo from './logo.svg';
import './App.css';
import Header from "./Header"
import Menu from "./Menu"
import MainContent from './MainContent';

function App() {
  return (
    <div >
      <Header></Header>
      <Menu></Menu>
      <MainContent></MainContent>
      </div>
  );
}

export default App;
