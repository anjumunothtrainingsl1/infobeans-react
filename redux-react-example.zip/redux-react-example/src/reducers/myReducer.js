function myReducer(state,action)
{
  console.log("Reducer executed")
  var newState={...state};
  switch(action.type)
  {
    case "ADD":
        newState.empArr.push(action.payload);
      break;
    case "DEL":
        var pos=newState.empArr.findIndex(item=>item.empId==action.payload.empId)
        if(pos>=0)
        {
          newState.empArr.splice(pos,1)
        }
      break;
  }
  return newState
}

export default myReducer;