import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

import  store  from "./store/myStore"
import { Provider } from "react-redux"


ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
/*
import {createStore} from "redux"
const addAction={type:"ADD",payload:{empId:201,empName:"sara",salary:76889}}

const delAction={type:"DEL",payload:{empId:201}}



var myState={empArr:[{
  "empId": 101,
  "empName": "asha",
  "salary": 1001,
  "deptId": "D1"
}, {
  "empId": 102,
  "empName": "Gaurav",
  "salary": 2000,
  "deptId": "D1"
}, {
  "empId": 103,
  "empName": "Karan",
  "salary": 2000,
  "deptId": "D2"
},
{
  "empId": 104,
  "empName": "Kishan",
  "salary": 3000,
  "deptId": "D1"
},
{
  "empId": 105,
  "empName": "Keshav",
  "salary": 3500,
  "deptId": "D2"
},
{
  "empId": 106,
  "empName": "Pran",
  "salary": 4000
},
{
  "empId": 107,
  "empName": "Saurav",
  "salary": 3800
}
]}
var store=createStore(myReducer,myState)

store.subscribe(()=>{
  console.log("State :",store.getState());
})

//call the reducer implicitly 1. state 2.action
store.dispatch(addAction);;

store.dispatch({type:"ADD",payload:{empId:202,"empName":"tara",salary:6666}})

// unidirectional flow of data; modification of data -- dispatching an action ;
// cant call the reducer directly; cant modify the state directly
// sequentially
// multiple reducers -- combineReducers()
// state-- object; multiple fields
// store- 1; state-1

function delActionCreator(p1)
{
  return {type:"DEL",payload:{empId:p1}}
}

store.dispatch(delActionCreator(103))






 */