import logo from './logo.svg';
import './App.css';
import Emp from "./Emp"

function App() {
  return (
    <div> 
      Employee details
      <Emp></Emp>
    </div>
  );
}

export default App;
