import React from "react"
import {connect} from "react-redux"
// store.getState()

function mapStateToProps(state)
{
    return state;
}

function mapDispatchToProps(dispatch)
{
    return (
        {
            myAddAction:(p1)=> dispatch(p1)
        }
    )
}
class Emp extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state={empArr:props.empArr}
    }
    addEmpClickHandler=()=>{
        // dispatch an action ADD 
        var myAction={type:"ADD",payload:{empId:301,empName:"jack"}}
        this.props.myAddAction(myAction)

    }
    render()
    {
        console.log(this.props);
        return(
            <div>
                <h1> Emp Details</h1>
                <ul>
                    {this.props.empArr.map((item)=>{
                        return(
                        <li key={item.empId}>{item.empName}</li>
                        )
                    })
                    }
                </ul>
                <input type="button" value="Add emp" onClick={this.addEmpClickHandler} />
            </div>
        )
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Emp)