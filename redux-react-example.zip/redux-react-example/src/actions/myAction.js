const addAction={type:"ADD",payload:{empId:201,empName:"sara",salary:76889}}

const delAction={type:"DEL",payload:{empId:201}}

function delActionCreator(p1)
{
  return {type:"DEL",payload:{empId:p1}}
}

module.exports={addAction:addAction,delAction,delActionCreator}