import React from 'react'

export default function EmpDetails(props)
{
    console.log(props)
    
    return(
        <React.Fragment>
            <h1>
                Emp Details
            </h1>
            <h3> Emp Id: {props.match.params.eId}</h3>
            <h3> Emp Name :{props.location.state.data.empName}</h3>
            <h3> Location :{props.location.state.myLocation}</h3>
            <input type="button" value="Go Back" onClick={()=>{
                props.history.goBack();
            }} />
            </React.Fragment>
    )
}
