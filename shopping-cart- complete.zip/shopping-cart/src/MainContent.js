import React, { Component } from 'react'
import { Route, Switch } from 'react-router-dom'
import AboutUs from './AboutUs'
import DisplayCart from './DisplayCart'
import DisplayProducts from './DisplayProducts'
import Feedback from "./Feedback"
import EmpDetails from "./EmpDetails"
import Books from './Books'
import Register from "./Register"
import Welcome from "./Welcome"
import Courses from './Courses'
import DataFromServer from './DataFromServer'
function ContactUs() {
    return (
        <React.Fragment>
            <h1> ContactUs Component</h1>
        </React.Fragment>
    )
}

class MainContent extends Component {
    constructor() {
        super()
        this.state = { showCart: false, cartArr: [] }
    }
    showComponentEventHandler = (p1) => {
        this.setState({ showCart: p1 })

    }
    onDataFromDPEventHandler = (p1) => {
        console.log("Data from Dp", p1)
        this.setState((prevState) => {
            var tempCartArr = [...this.state.cartArr]
            tempCartArr.push(p1)
            return { ...prevState, cartArr: tempCartArr }
        })

    }
    render() {
        return (
            <React.Fragment>
                <Switch>
                    <Route path="/datafromserver" component={DataFromServer}></Route>
                    <Route path="/courses" component={Courses}></Route>
                    <Route path="/welcome" component={Welcome} ></Route> 
                    <Route path="/register" component={Register} ></Route>
                    <Route path="/books" component={Books} ></Route>
                    <Route path="/products" >
                     <DisplayProducts  onDataFromDP={this.onDataFromDPEventHandler}></DisplayProducts>
                    </Route>
                    <Route path="/cart" render={(props) => {
                        return (
                            <DisplayCart {...props}  cartArr={this.state.cartArr}></DisplayCart>
                        )

                    }}></Route>
                    <Route path="/aboutus" component={AboutUs}></Route>
                    <Route path="/contactus" component={ContactUs} ></Route>
                    <Route path="/feedback" component={Feedback}></Route>
                    <Route path="/emp/:eId" component={EmpDetails}></Route>
                    <Route path="/" component={DisplayProducts} exact ></Route>
                    <Route render={() => { return (<h1> Page not found</h1>) }}></Route>
                </Switch>
            </React.Fragment>)
    }
}
export default MainContent