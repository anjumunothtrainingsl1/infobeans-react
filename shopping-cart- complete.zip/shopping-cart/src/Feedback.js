import React from 'react'

export default function Feedback()
{
    return (<React.Fragment>
        <h1>Feedback Component</h1>
    </React.Fragment>)
}

