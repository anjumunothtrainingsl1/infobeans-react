import React from "react"

class Login extends React.Component {
    constructor(props)
    {
        super(props)
        this.userNametxtBox=React.createRef()
        this.passwordtxtBox=React.createRef()
    }

    
    loginEventHandler=()=>{
        alert(`Hi username:${this.userNametxtBox.current.value} and password:${this.passwordtxtBox.current.value}`)
    }
    render() {


        return (
            <React.Fragment>
                <form>
                    <input type="text" placeholder="Enter Username" ref={this.userNametxtBox} />
                    <input type="text" placeholder="Enter Password" ref={this.passwordtxtBox}/>
                    <input type="button" value="Login" onClick={this.loginEventHandler} />
                </form>
            </React.Fragment>
        );
    }
}

export default Login;