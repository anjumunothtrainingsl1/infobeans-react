import React from 'react'
import axios from "axios"
import Hooks2 from './Hooks2'

class DataFromServer extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state={usersArr:[],productsArr:[],responseText:"",showHooks:false}
    }
    getRequest()
    {
        axios.get("http://localhost:3001/api/products")
        .then((response)=>{
            console.log(response);
            this.setState({productsArr:response.data})

        })
        .catch((err)=>{console.log("Error",err)})
    }
    componentDidMount()
    {
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then((response)=>{
            console.log(response);
            this.setState({usersArr:response.data})

        })
        .catch((err)=>{console.log("Error",err)})
        this.getRequest()
        
    }
    postEventHandler=()=>{
        var myData={"productId":7,"productName":"Oppo","price":8787,"imageUrl":"./iphoneXR.jpg","quantity":10,"description":"Nokia series"}
        axios.post("http://localhost:3001/api/products",myData)
        .then((response)=>{
            //console.log(response);
            console.log(response.statusText)
            this.setState({responseText:response.data})
            this.getRequest()

        })
        .catch((err)=>{console.log("Error",err)})
        
    }
    putEventHandler=()=>{
        var myData={"productId":2,"productName":"Huawei","price":8787,"imageUrl":"./iphoneXR.jpg","quantity":10,"description":"Huawei"}
        axios.put("http://localhost:3001/api/products",myData)
        .then((response)=>{
            console.log(response);
            this.setState({responseText:response.data})
            this.getRequest()
        })
        .catch((err)=>{console.log("Error",err)})
        

    }
    deleteEventHandler=()=>{
        axios.delete("http://localhost:3001/api/products/5")
        .then((response)=>{
            console.log(response);
            this.setState({responseText:response.data})
            this.getRequest()
        })
        .catch((err)=>{console.log("Error",err)})
    }
    render()
    {
        var userNameArr=this.state.usersArr.map((item)=>{
            return(
                <li key={item.id}> {item.username}</li>
            )

        })
        var productsNameArr=this.state.productsArr.map((item)=>{
            return(
                <li key={item.productId}> {item.productName}</li>
            )

        })
        return(
            <React.Fragment>
                <h1> Data from Server Component</h1>
                {this.state.showHooks &&<Hooks2 arrLength={this.state.productsArr.length}></Hooks2>}
                <input type="button" value="Show hooks" onClick={()=>{this.setState({showHooks:true})}} />
                <input type="button" value="Remove hooks" onClick={()=>{this.setState({showHooks:false})}} />
                
                <ul>
                    {userNameArr}
                </ul>
                <ul>
                    {productsNameArr}
                </ul>
                <input type="button" value="Post" onClick={this.postEventHandler} />
                <input type="button" value="Put" onClick={this.putEventHandler} />
                <input type="button" value="Delete" onClick={this.deleteEventHandler} />
                {this.state.responseText}

            </React.Fragment>
        )
    }
}

export default DataFromServer

//REST api ; get request