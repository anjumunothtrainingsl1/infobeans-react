import logo from './logo.svg';
import React from "react"
import Header from './Header';
import DisplayCart from './DisplayCart';
import DisplayProducts from './DisplayProducts';
import Parent from './Parent';
import Menu from './Menu';
import MainContent from './MainContent';

class App extends React.Component {
  
  render() {
    return (
      <React.Fragment>
        <Header></Header>
        <Menu></Menu>
        <MainContent></MainContent>
        {/* {this.state.showCart?
        <DisplayCart cartArr={this.state.cartArr}></DisplayCart>:
        <DisplayProducts onDataFromDP={this.onDataFromDPEventHandler}></DisplayProducts>} */}
      </React.Fragment>
    
  );
  }
}

export default App;
