import React from "react"
import Login from "./Login"

function Main()
{
    return(
        <React.Fragment>
            <Login></Login>
        </React.Fragment>
    )
}

export default Main;