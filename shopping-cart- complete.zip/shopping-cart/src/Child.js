
import React from 'react'

class Child extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state={newValue:1}
    }
    sendDataEventHandler=()=>{
        this.setState({newValue:this.props.sendDataToChild *2},()=>{
            this.props.onMyClick(this.state.newValue)
        })
        
    }
    render()
    {
        console.log(this.props.sendDataToChild)
        return(
            <React.Fragment>
                <h1> Child Component</h1>
                <input type="button" value="Send the data to parent" onClick={this.sendDataEventHandler}/>
                {this.state.newValue}
            </React.Fragment>
        )

    }
}

export default Child