import React from 'react'
import PropTypes from "prop-types"

export default class EmpEdit extends React.Component
{
    render()
    {
        
        return (
            <div>
               EmpId {this.props.emp.empId}
               {this.props.emp.empName}
               {this.props.emp.salary}
            </div>
        )
    }
}
EmpEdit.defaultProps={"emp.empName":"sara"}
EmpEdit.propTypes={
    emp:PropTypes.exact({
        empId:PropTypes.number.isRequired,
        empName:PropTypes.string.isRequired,
        salary:PropTypes.number.isRequired,
    }).isRequired,
    customValidation:function(props,propName,componentName)
    {

        if (typeof props["emp"]["salary"] == "number" )
        {
            if (props["emp"]["salary"] <0 )
            {
                return new Error("Salary cannot be negative")
            }
        }
        else
        {
            return new Error("Salary should be a number")
        }
    }
   
}

  