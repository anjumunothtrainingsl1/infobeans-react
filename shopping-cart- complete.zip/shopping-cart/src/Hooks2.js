import React,{useState,useEffect} from 'react'
import axios from "axios"

function Hooks2(props)
{
    // useState("anju"); constructor: this.setState({firstName:"anju"})
    var [firstName,setFirstName]=useState("anju");

    var [lastName,setLastName]=useState("munoth")

    var [gender,setGender]=useState("female")

    var [emp,setEmp]=useState({empId:101,empName:"sara"})

    var [productsArr,setProductsArr]=useState([])
    

    var onchangeEventHandler=(event)=>{
        console.log(event.target.value)
        setFirstName(event.target.value)
        // this.setState({firstName:event.target.value})
    }
    var onchangeLastNameEventHandler=(event)=>{
        console.log(event.target.value)
        setLastName(event.target.value)
        // this.setState({firstName:event.target.value})
    }
    var welcomeEventHandler=()=>{
        alert("Welcome "+firstName)
    }
    // server request which should be excuted only once
    //2 params; 1param -- function ; 2 param -- array
    // 2 param is an empty array --- useEffect will be called only once
    //componentDidMount
    useEffect(()=>{
        console.log("axios get request")
        axios.get("http://localhost:3001/api/products")
        .then((response)=>{
            console.log(response);
           // this.setState({productsArr:response.data})
           setProductsArr(response.data)

        })
        .catch((err)=>{console.log("Error",err)})
    },[]);


    // componentShouldUpdate(boolean), componentDidUpdate
    useEffect(()=>{
        console.log("I will be invoked only when firstName changes")

    },[firstName])

    // componentWillUnMount
    useEffect(()=>{
        return (()=>{
            console.log("Bye Hooks is going to be removed")
        })
    },[])

// getDerivedStateFromProps
useEffect(()=>{
            console.log("whenever the props changes")
           
       
    },[props])
    
    return(
        <React.Fragment>
            <input type="text" placeholder="Enter the first name" onChange={onchangeEventHandler}/>
            <input type="text" placeholder="Enter the last name" onChange={onchangeLastNameEventHandler}/>
           
            <input type="button" value="Welcome" onClick={welcomeEventHandler} />

            First Name :{firstName}
            Last Name :{lastName}
            <table>
                        <tbody>
                        {productsArr.map((item)=>{
                return (
                   <tr key={item.productId}>
                       <td>{item.productName}</td>
                       <td>{item.description}</td>
                   </tr>
                )
            })}
                        </tbody>
                    </table>
            
        </React.Fragment>
    )
}

export default Hooks2;