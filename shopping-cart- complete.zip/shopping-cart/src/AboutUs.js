import React from "react"
import EmpEdit from "./EmpEdit"

function AboutUs(props)
{
    var empArray=[{
		"empId": 101,
		"empName": "asha",
		"salary": 1001,
		"deptId": "D1"
	}, {
		"empId": 102,
		"empName": "Gaurav",
		"salary": 2000,
		"deptId": "D1"
	}, {
		"empId": 103,
		"empName": "Karan",
		"salary": 2000,
		"deptId": "D2"
	},
	{
		"empId": 104,
		"empName": "Kishan",
		"salary": 3000,
		"deptId": "D1"
	},
	{
		"empId": 105,
		"empName": "Keshav",
		"salary": 3500,
		"deptId": "D2"
	},
	{
		"empId": 106,
		"empName": "Pran",
		"salary": 4000
	},
	{
		"empId": 107,
		"empName": "Saurav",
		"salary": 3800
	}
];
	var sendDataAsQP=()=>{
		// /books?bookId=b1
		
	}
    var showDetailsEventHandler=(p1)=>{
        props.history.push("/emp/"+p1.empId,{data:p1,deptId:"d1",myLocation:"Indore"})
    }
    var trArray=empArray.map((item)=>{
        return(
            <tr key={item.empId}>
                <td>{item.empId}</td>
                <td>{item.empName}</td>
                <td>{item.salary}</td>
                <td>
                    <input type="button" value="Show Details" onClick={showDetailsEventHandler.bind(this,item)} />
                </td>
            </tr>
        )
    })
    console.log("Props in Aboutus",props)
    return(
        <React.Fragment>
            <h1> AboutUs Component</h1>
            <table className="table">
               <tbody>
                   {trArray}
               </tbody>
            </table>
            <input type="button" value="Go to Feedback" 
            onClick={()=>{ props.history.push("/feedback")}}/>
			<input type="button" value="Send data to Books as query params"
			onClick={()=>{props.history.push("/books?bookId=b1")}} />
			<EmpEdit emp={{empId:555,salary:7698}} ></EmpEdit>
        </React.Fragment>
    )
}

export default AboutUs;