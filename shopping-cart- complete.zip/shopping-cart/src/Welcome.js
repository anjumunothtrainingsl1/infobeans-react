import React from 'react'

export default function Welcome(props)
{
    var myString=props.location.search.toString().substring(1);
    var myArr=myString.split("&")
    var firstName=myArr[0].split("=")[1]
    var lastName=myArr[1].split("=")[1]
    return (
        <div>
            <h1> Welcome Details</h1>
            <h2> Welcome {firstName} {lastName}</h2>           
        </div>
    )
}