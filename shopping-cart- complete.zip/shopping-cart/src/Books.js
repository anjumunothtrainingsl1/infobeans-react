import React from "react"

export default function Books(props)
{
    console.log("Props in Books Component",props)
    var bookIdString=props.location.search.toString().substring(1);
    var qsArr=bookIdString.split("=")
    console.log(qsArr)


    return (
        <div>
            <h1>Books Component </h1>
        </div>
    )
}