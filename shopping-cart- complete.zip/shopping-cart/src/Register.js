import React from 'react'

export default function Register()
{
    return (
        <div>
            <h1> Register Details</h1>
            <form action="/welcome" >
                <input type="text" placeholder="Enter the firstName" name="txtFirstName" />
                <input type="text" placeholder="Enter the lastName" name="txtLastName" />
                <input type="submit" value="Register" />
            </form>
        </div>
    )
}