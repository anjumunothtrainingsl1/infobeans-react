import React from 'react'
import Details from './Details';
import ReactModal from "react-modal"

ReactModal.setAppElement(document.getElementById("root"))
class DisplayCart extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state={
            cartArr:this.props.cartArr,
            showDetails:false,
            selectedCartItem:{}}
        
    }
    detailsEventHandler=(p1)=>{
        this.setState({showDetails:true,selectedCartItem:p1})
    }
    closeDialog=()=>{
        this.setState({showDetails:false})
    }
    
    render()
    {
        console.log("Props in DisplayCart",this.props)
        var trArray=this.state.cartArr.map((item)=>{
                return (
                    <tr key={item.productId}>
                        <td>
                            <img src={item.imageUrl} alt={item.description} />
                        </td>
                        <td>{item.productName}</td>
                        <td>{item.description}</td>
                        <td>{item.price}</td>
                        <td>{item.quantitySelected}</td>
                        <td>{item.price * item .quantitySelected}</td>
                        <td>
                            <input type="button" value="Details" onClick={this.detailsEventHandler.bind(this,item)}/>
                        </td>
                    </tr>
                )
        })
              return (
                  <React.Fragment>
            <h1>DisplayCart Componnet</h1>

            <table className="table">
                <thead>
                    <tr>
                        <th>
                            Image
                        </th>
                        <th>
                            Product Name
                        </th>
                        <th>
                            Description
                        </th>
                        <th>
                            Price
                        </th>
                        <th>
                            Quantity Purchased
                        </th>
                        <th>
                            Total
                        </th>
                        <th>
                            Details
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {trArray.length >0 ?trArray:<h1> No items added to the cart yet</h1>}
                </tbody>
            </table>
            <ReactModal  shouldFocusAfterRender={true}
            isOpen={this.state.showDetails} 
            shouldCloseOnEsc={true} 
            shouldCloseOnOverlayClick={true}
            onRequestClose={this.closeDialog}
            style={{content:{backgroundColor:"pink"},overlay:{backgroundColor:"cyan"}}}
            >
            <Details selectedItem={this.state.selectedCartItem} closeDialog={this.closeDialog}></Details>
           
            </ReactModal>
            </React.Fragment>
        )
    }
}

export default DisplayCart