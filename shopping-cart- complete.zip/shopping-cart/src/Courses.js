import React from 'react'
import {Link,Route,Redirect} from "react-router-dom"
import "./Courses.css"
// /courses/angular ---> Angular 
// /courses/react ---> React
// /courses/mongodb ---> Mongodb

function Angular() {
    return (<h1>Angular Component</h1>)
}
function ReactComponent() {
    return (<h1>React Component</h1>)
}
function MongoDb() {
    return (<h1>MongoDb Component</h1>)
}


export default function Courses({ match, location }) {
    var basePath=match.path
    return (
        <div>
            <ul className="ulList">
                <li className="liItem">
                    <Link to={`${basePath}/angular`} className="linkItem">Angular</Link>
                </li>
                <li className="liItem">
                    <Link to={`${basePath}/react`}  className="linkItem">React</Link>
                </li>
                <li className="liItem">
                    <Link to={`${basePath}/mongodb`}  className="linkItem">Mongodb</Link>
                </li>
            </ul>
            
            <div>
                <Route path={`${basePath}/angular`} strict component={Angular}></Route>
                <Route path={`${basePath}/react`} strict component={ReactComponent}></Route>
                <Route path={`${basePath}/mongodb`} strict component={MongoDb}></Route>
                <Redirect path={`${basePath}`} to={`${basePath}/angular`} exact></Redirect>
            </div>
        </div>
    )
}