import React from 'react'

function Hooks1()
{
    return(
        <React.Fragment>
            
        </React.Fragment>
    )
}

export default Hooks1;