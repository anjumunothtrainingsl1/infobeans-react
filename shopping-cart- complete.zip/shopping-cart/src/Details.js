import React from "react"

class Details extends React.Component
{
    constructor(props)
    {
        super(props)
        this.inputText=React.createRef()
    }
    componentDidMount()
    {
        
        this.inputText.current.focus();
    }
    closeEventHandler=()=>{
        this.props.closeDialog();
    }
    render()
    {
        console.log(this.props.selectedItem)
        return (
            <React.Fragment>
                <h1> Details Component</h1>
                <input type="text" ref={this.inputText} />
                <input type="button" value="Close" onClick={this.closeEventHandler}/>
            </React.Fragment>
        )
    }
}

export default Details